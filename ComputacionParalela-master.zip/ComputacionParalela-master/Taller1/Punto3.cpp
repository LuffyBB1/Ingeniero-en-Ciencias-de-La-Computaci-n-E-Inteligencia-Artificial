/*Materia : Computacion Paralela
 *Fecha : 1/2/2022
 *Autor : Juan Camilo Rodriguez
 *Tema : Taller
 *Punto: 3
*/
#include <stdio.h>  
int main()  
{ 
	int x = 0;  
	for (x = 'a'; x <= 'z'; x += 10){  
	printf("%c ", x ); 
	}  
} 
