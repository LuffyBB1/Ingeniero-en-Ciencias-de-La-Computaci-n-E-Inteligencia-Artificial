/*
* Date: 2022-02-010
* Author: Juan Camilo Rodriguez
* Course: Paralell and Distributed Computing
* Topic: Programacion modular en C
* Fichero: Interfaz del modulo funciones.c
*/
/* Se presenta la cabecera del modulo*/

#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

int Sumar(int val_1, int val_2);

#endif