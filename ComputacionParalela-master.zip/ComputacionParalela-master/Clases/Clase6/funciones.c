/*
* Date: 2022-02-010
* Author: Juan Camilo Rodriguez
* Course: Paralell and Distributed Computing
* Topic: Programacion modular en C
* Fichero: Modulo de funciones

* Creacion del objeto: gcc -ansi -pedantic -Wall -c funciones.c

*/
/* Se presenta la cabecera del modulo*/

#include "funciones.h"

int Sumar(int val_1, int val_2){
	return val_1 + val_2;
}