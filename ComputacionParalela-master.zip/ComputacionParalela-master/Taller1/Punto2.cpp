/*Materia : Computacion Paralela
 *Fecha : 1/2/2022
 *Autor : Juan Camilo Rodriguez
 *Tema : Taller
 *Punto: 2
*/
#include <stdio.h>  
int	main()  
{  
	int x = 1, y = 1;  
	if (x == 1)  
		if (y == 0)  
			x = 10;  
	else  
		x = -1;  
	printf("%d\n", x);  
} 
 