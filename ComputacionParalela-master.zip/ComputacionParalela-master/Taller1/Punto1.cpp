/*Materia : Computacion Paralela
 *Fecha : 1/2/2022
 *Autor : Juan Camilo Rodriguez
 *Tema : Taller
 *Punto: 1
*/
#include <stdio.h>
int main()
{
	int x = 1, y = 1;
	if (x = y * 5)
		x = 0;
	else
		x = -1;
	printf("%d\n", x);
}